export const SHIPPING=5.55
export const TAXES=5
export const ITEMS_PER_PAGE=10